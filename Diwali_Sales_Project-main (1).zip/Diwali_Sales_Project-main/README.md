# Diwali_Sales_Project
This project entails an analysis of Diwali sales data. A mpa was populated sing Power BI to indicate the location of the Sales. Population data for India was extracted from wikipedia and the the tables were merged. A new colum was created for Sales per Capita.
